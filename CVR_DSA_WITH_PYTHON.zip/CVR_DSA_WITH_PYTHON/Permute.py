
# [1] ==> [[1]]

def permute(arr):
    n = len(arr)
    if n == 1:
        return [arr]
    ans = []
    for i in range(n):
        fixedEle = arr[i]
        subSequence = arr[0:i]+arr[i+1:]
        all = permute(subSequence)
        for per in all:
            per.append(fixedEle)
            ans.append(per)
    return ans


def main():
    arr = [1,2,3]
    ans = permute(arr)
    print(ans)
main()
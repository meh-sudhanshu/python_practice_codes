
def getLengthOfLongestIncreasingSequence(arr):
    dict = {}
    for e in arr:
        if e not in dict:
            dict[e] = 1
        else:
            dict[e]+=1
    ans = 0
    for e in arr:
        currAns = 0
        if e-1 not in dict:
            val = e
            while True:
                if val in dict:
                    currAns+=1
                    val+=1
                else:
                    break
        if currAns > ans:
            ans = currAns
    return ans




def printAllSubsequence(arr,i,curr):
    if i == len(arr):
        print(curr)
        return
    printAllSubsequence(arr,i+1,curr+[arr[i]])
    printAllSubsequence(arr,i+1,curr)
    


def main():
    arr = [1,2,3]
    # ans = getLengthOfLongestIncreasingSequence(arr)
    # print(ans)
    printAllSubsequence(arr,0,[])
main()
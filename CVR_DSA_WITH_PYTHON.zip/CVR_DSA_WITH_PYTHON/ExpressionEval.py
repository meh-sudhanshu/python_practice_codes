
def isOperator(ch):
    if ch == '+' or ch == "-" or ch == '*' or ch == '/':
        return True
    return False
def evaluate(p1,p2,ch):
    if ch == '+':
        return p2+p1
    elif ch == '*':
        return p2*p1
    elif ch == '-':
        return p2-p1
    else:
        return p2//p1


def evalPostfix(arr):
    n = len(arr)
    st = []
    for i in range(n):
        ch = arr[i]
        if isOperator(ch):
            p1 = st.pop()
            p2 = st.pop()
            result = evaluate(p1,p2,ch)
            st.append(result)
        else:
            st.append(ch)
    return (st[0])



def main():
    postFix = [2,3,1,'*','+',9,'-']
    #prefix = ['+','*',5,4,'-',10,2]
    ans1 = evalPostfix(postFix)
    print(ans1)
    #ans2 = evalPrefix(prefix)
    #print(ans2)
main()



# java, c , c++ ----> int[] arr;

def getNextGtreatersForAllElement(arr):
    st = []
    n = len(arr)
    ans = [-1 for i in range(n)]
    for i in range(n-1,-1,-1):
        ele = arr[i]
        while len(st) != 0 and st[-1] < ele:
            st.pop()
        if len(st) == 0:
            ans[i] = -1
        else:
            ans[i] = st[-1]
        st.append(ele)
    return ans
        

def main():
    arr = [2,3,-1,5,18,3,2,1,10,12,-3]
    ans = getNextGtreatersForAllElement(arr)
    print(ans)

main()
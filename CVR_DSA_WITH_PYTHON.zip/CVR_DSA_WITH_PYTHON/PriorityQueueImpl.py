# import queue



# priorityQueue = queue.PriorityQueue()
# priorityQueue.put((1,"Ele1"))
# priorityQueue.put((2,"Ele2"))
# priorityQueue.put((3,"Ele3"))
# priorityQueue.put((4,"Ele4"))

# firstGet = priorityQueue.get()
# print(firstGet[0])
# print(firstGet[1])

# print(priorityQueue.qsize())

a = 10
# if a> 10:
#     print("greater than 10")
# else:
#     print("less than 10")

if(a > 10){
    print("Greater")
}else{
    print("smaller")
}




def main():
    _str = "malayalam"
    n = len(_str)
    dp = [[0 for i in range(n)] for j in range(n)]
    row = 0
    col = 0
    count = 0
    while col < n:
        colCopy = col
        while colCopy < n:
            #print(dp[row][colCopy],end = " ")
            if colCopy - row <= 2:
                if _str[row] == _str[colCopy]:
                    dp[row][colCopy] = 1
                    count+=1
            else:
                if _str[colCopy] == _str[row]:
                    if dp[row+1][colCopy-1] == 1:
                        dp[row][colCopy] = 1
                        count+=1
            row+=1
            colCopy+=1
        #print()
        row= 0
        col+=1
    print(count)
main()
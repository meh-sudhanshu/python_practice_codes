


def main():
    n = 5
    k = 5
    dp = [0 for i in range(n+1)]
    dp[1] = 1
    dp[2] = 2
    sum = 3
    for i in range(3,k+1):
        dp[i] = sum+1
        sum = sum+dp[i]  
    i = 1
    j = k
    for z in range(k+1,n+1):
        dp[z] = sum
        i+=1
        j+=1
        sum = sum - dp[i-1] + dp[j]
    print(dp[n])

main()


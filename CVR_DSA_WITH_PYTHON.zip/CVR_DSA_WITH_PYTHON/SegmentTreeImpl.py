
arr = [3,8,9,-5,2,1,4,18,-3,9]
n = len(arr)
segmentTree = [float("-inf") for i in range(4*n)]



def buildSegmentTree(rootIndex,low,high):
    if low == high:
        segmentTree[rootIndex] = arr[low]
        return
    mid = (low+high)//2
    buildSegmentTree(2*rootIndex+1,low,mid)
    buildSegmentTree(2*rootIndex+2,mid+1,high)
    segmentTree[rootIndex] = max(segmentTree[2*rootIndex+1],segmentTree[2*rootIndex+2])
    
def getAnsForCurrentQuery(rootIndex,low,high,left,right):

    # 0,0,n-1,3,6

    if low>= left and high<=right:
        return segmentTree[rootIndex]
    if high < left or low > right:
        return float("-inf")

    mid = (low+high)//2
    leftAns = getAnsForCurrentQuery(rootIndex*2 + 1, low,mid,left,right)
    rightAns = getAnsForCurrentQuery(rootIndex*2 + 2, mid+1,high,left,right)
    return max(leftAns,rightAns)



def main():
    buildSegmentTree(0,0,n-1)
    print(segmentTree)
    queries = [[3,6],[0,6],[2,7],[1,4]]
    for query in queries:
        l = query[0]
        r = query[1]
        ans = getAnsForCurrentQuery(0,0,n-1,l,r)
        print(ans,end=" ")

main()
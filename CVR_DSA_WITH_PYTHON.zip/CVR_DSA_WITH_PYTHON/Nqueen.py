

def nQueen(chessBoard,n,col,diag,revDiag,rowNumber):
    if rowNumber >= n:
        for row in chessBoard:
            for val in row:
                print(val,end=" ")
            print()
        print("---------------------------------------------------")
        return
    row = chessBoard[rowNumber]
    for i in range(n):
        if col[i] == 0 and diag[(rowNumber-i)+n] == 0 and revDiag[i+rowNumber] == 0:
            col[i] = 1
            diag[(rowNumber-i)+n] = 1
            revDiag[i+rowNumber] = 1
            chessBoard[rowNumber][i] = 1
            nQueen(chessBoard,n,col,diag,revDiag,rowNumber+1)
            col[i] = 0
            diag[(rowNumber-i)+n] = 0
            revDiag[i+rowNumber] = 0
            chessBoard[rowNumber][i] = 0








def main():
    n = 8
    col = [0 for i in range(n)]
    diag = [0 for i in ran ]
    revDiag = [0 for i in range(2*n - 1)]
    chessBoard = [[0 for i in range(n)] for j in range(n)]
    nQueen(chessBoard,n,col,diag,revDiag,0)
main()
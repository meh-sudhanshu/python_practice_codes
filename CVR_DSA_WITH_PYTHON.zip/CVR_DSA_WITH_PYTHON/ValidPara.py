
def isValid(_str):
    n = len(_str)
    st = []
    for i in range(n):
        ch = _str[i]
        if ch == '(' or ch == '{' or ch == '[':
            # if ch in "({["
            st.append(ch)
        else:
            if len(st) == 0: return False
            if ch == ')' and st.pop() != '(':
                return False
            if ch == ']' and st.pop() != '[':
                return False
            if ch == '}' and st.pop() != '{':
                return False
    return len(st) == 0

def main():
    _str = "[[]{}((){})]"
    ans = isValid(_str)
    print(ans)
main()
class Node:
    def __init__(self):
        self.childrens = {}
        self.isEndOfWord = False

class Trie:
    def __init__(self):
        self.root = Node()

    def insert(self,word):
        current = self.root
        for ch in word:
            if ch not in current.childrens:
                current.childrens[ch] = Node()
                current = current.childrens[ch]            
            else:
                current = current.childrens[ch]
        current.isEndOfWord = True
        
    def serach(self,word):
        current = self.root
        for ch in word:
            if ch not in current.childrens:
                return False
            else:
                current = current.childrens[ch]
        return current.isEndOfWord
    
    def startsWith(self,prefix):
        current = self.root
        for ch in prefix:
            if ch not in current.childrens:
                return False
            else:
                current = current.childrens[ch]
        return True
    
    def countTotalWordsThatStartsWith(self,prefix):
        def dfs(node):
            count = 1 if node.isEndOfWord == True else 0
            for child in node.childrens.values():
                count+=dfs(child)
            return count 

        current = self.root
        for ch in prefix:
            if ch not in current.childrens:
                return 0
            else:
                current = current.childrens[ch]
        return dfs(current)
    
    def getAllWordsThatStartsWith(self,prefix):
        def dfs(node,SSF):
            if node.isEndOfWord == True:
                print(SSF,end=" ")
            for key,value in node.childrens.items():
                dfs(value,SSF+key)
        current = self.root
        for ch in prefix:
            if ch not in current.childrens:
                return 0
            else:
                current = current.childrens[ch]
        return dfs(current,prefix)



           

def main():
    words = ["apple","app","axe","eat","eaten","apps","abs","eats","eating"]
    trie = Trie()
    for word in words:
        trie.insert(word)
    #print(trie.serach("ap"))
    #print(trie.startsWith("eax"))
    #print(trie.countTotalWordsThatStartsWith("eat"))
    trie.getAllWordsThatStartsWith("ea")


main()
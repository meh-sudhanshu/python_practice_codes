import queue

largestPath = ""
shortestPath = ""
minCostOfAnyPath = float("+inf")
maxCostOfAnyPath = float("-inf")
minCostPath = ""
maxCostPath = ""

class Pair:
    def __init__(self,node,psf):
        self.node = node
        self.psf = psf


def buildGraph(n,edges):
    graph = [[0 for i in range(n)] for j in range(n)]
    for edge in edges:
        src = edge[0]
        des = edge[1]
        #wt = edge[2]
        graph[src][des] = 1
        #graph[des][src] = wt
    return graph



def hasPath(graph,src,des,visited):
    if src == des:
        return True
    
    visited[src] = 1
    
    nbrs = graph[src]
    for i in range(len(nbrs)):
        if nbrs[i] != 0 and visited[i] != 1:
            ans = hasPath(graph,i,des,visited)
            if ans == True:
                return True
    return False

def getCurrentComponent(graph,i,visited,csf):
    nbrs = graph[i]
    for j in range(len(nbrs)):
        if nbrs[j] != 0 and visited[j] == 0:
            visited[j] = 1
            csf,visited = getCurrentComponent(graph,j,visited,csf+"->"+str(j))

    return csf,visited
            

def getAllComponent(graph,n,visited):

    allComponents = []

    for i in range(n):
        if visited[i] == 0:
            visited[i] = 1
            currComponent,visited = getCurrentComponent(graph,i,visited, str(i))
            allComponents.append(currComponent)
    return allComponents





def printAllPath(graph,src,des,visited,psf,wsf):
     global largestPath
     global shortestPath
     global minCostOfAnyPath
     global maxCostOfAnyPath
     global minCostPath
     global maxCostPath
     if src == des:
        if wsf < minCostOfAnyPath:
             minCostOfAnyPath = wsf
             minCostPath = psf
        if wsf > maxCostOfAnyPath:
            maxCostOfAnyPath = wsf
            maxCostPath = psf

        if len(largestPath) == 0 or len(largestPath) < len(psf):
            largestPath = psf
        
        if len(psf) < len(shortestPath) or len(shortestPath) == 0:
            shortestPath = psf

             
        
        return
     visited[src] = 1
     #work
     nbrs = graph[src]
     for i in range(len(nbrs)):
         if nbrs[i] != 0 and visited[i] != 1:
             printAllPath(graph,i,des,visited,psf+"->"+str(i),wsf+graph[src][i])
     visited[src] = 0
     

def bfs(graph,n):
    initialPair = Pair(0,str(0))
    queue = [initialPair]
    visited = [0 for i in range(n)]

    while queue:
        # add nbrs, mark*, do the work, pop
        peek = queue[0]
        node = peek.node
        psf = peek.psf
        nbrs = graph[node]
        for i in range(len(nbrs)):
            if nbrs[i] != 0 and visited[i] == 0:
                pair = Pair(i,psf+"->"+str(i))
                queue.append(pair)
        visited[node] = 1
        print(node,psf)
        queue.pop(0)


def prism(graph,n):
    visited = [0 for i in range(n)]
    # cost, arriving-node, des
    #visited[0] = 1
    initialTuple = (0,-1,0)
    myQueue = queue.PriorityQueue()
    myQueue.put(initialTuple)
    while myQueue.qsize() != 0:
        currNode = myQueue.get()
        des = currNode[2]
        arrivingNode = currNode[1]
        cost = currNode[0]
        if visited[des] == 1:
            continue
        else:
            visited[des] = 1
            if arrivingNode != -1:
                print(des,"via",arrivingNode,cost)
            
            nbrs = graph[des]
            for i in range(len(nbrs)):
                if nbrs[i] != 0 and visited[i] == 0:
                    updatedDes = i
                    updatedArrivingNode = des
                    currCost = graph[des][i]
                    updatedTuple = (currCost,updatedArrivingNode,updatedDes)
                    myQueue.put(updatedTuple)





def dijkstra(graph,n):
    visited = [0 for i in range(n)]
    # weight, psf, des
    #visited[0] = 1
    initialTuple = (0,str(0),0)
    myQueue = queue.PriorityQueue()
    myQueue.put(initialTuple)
    while myQueue.qsize() != 0:
        currNode = myQueue.get()
        wt = currNode[0]
        psf = currNode[1]
        des = currNode[2]
        if visited[des] == 1:
            continue
        else:
            visited[des] = 1
            print(des,"via",psf,"with cost",wt)
            nbrs = graph[des]
            for i in range(len(nbrs)):
                if nbrs[i] != 0 and visited[i] == 0:
                    cost = graph[des][i]
                    updatedWt = wt + cost
                    # psf+=str(i)
                    updatedTuple = (updatedWt,psf+str(i),i)
                    myQueue.put(updatedTuple)
def expandNode(graph,n,i,visited,st):
    visited[i] = 1
    nbrs = graph[i]
    #isExpansionPossible = False
    for j in range(len(nbrs)):
        if nbrs[j] != 0 and visited[j] == 0:
            isExpansionPossible = True
            visited, st = expandNode(graph,n,j,visited,st)
    st.append(i)
    return visited,st


def topologicalSort(graph,n):
    visited = [0 for i in range(n)]
    st = []
    for i in range(n):
        if visited[i] == 0:
            visited, st = expandNode(graph,n,i,visited,st)
    print(st)



def main():
    n = 11
    edges = [[0,1],[1,2],[3,2],[4,2],[4,5],[4,6],[7,4],[8,4],[4,9],[9,10]]
    graph = buildGraph(n,edges)
    #visited = [0 for i in range(n)]
    #bfs(graph,n)
    #isPathExist = hasPath(graph,0,7,visited)
    #print(isPathExist)
    # printAllPath(graph,0,6,visited,str(0),0)
    # print("largestPath",largestPath)
    # print("shortestPath",shortestPath)
    # print("minCostOfAnyPath",minCostOfAnyPath)
    # print("maxCostOfAnyPath",maxCostOfAnyPath)
    # print("minCostPath",minCostPath)
    # print("maxCostPath",maxCostPath)
    ##allComponents = getAllComponent(graph,n,visited)
    #print(allComponents)
    #dijkstra(graph,n)
    #prism(graph,n)
    # for row in graph:
    #     for e in row:
    #         print(e,end=" ")
    #     print()
    topologicalSort(graph,n)

main()

# 0 via 0 with cost 0
# 2 via 02 with cost 3
# 3 via 023 with cost 5
# 1 via 0231 with cost 6
# 4 via 0234 with cost 11
# 5 via 02345 with cost 13
# 7 via 023457 with cost 16
# 6 via 02346 with cost 16
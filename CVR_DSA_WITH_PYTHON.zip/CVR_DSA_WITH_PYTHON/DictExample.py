
def tryInserting(a):
    a['a'] = 10


def main():
    myDict = {}
    tryInserting(myDict)
    print(myDict)

main()